﻿namespace invoice.Models
{
    public class Page
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public string Image { get; set; }
        public string Infooter { get; set; }
        public string Inheader { get; set; }

        //language 




    }
}
