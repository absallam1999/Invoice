﻿using Microsoft.AspNetCore.Identity;

namespace invoice.Models
{
    public class ApplicationUser: IdentityUser
    {
    }
}
