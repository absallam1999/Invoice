﻿namespace invoice.Models
{
    public class PurchaseCompletionOptionscs
    {
        public int Id { get; set; }
    }
}
